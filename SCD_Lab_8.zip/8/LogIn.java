/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab_8;

import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class LogIn extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton logInButton;
    private Connection connection;

    public LogIn(Connection connection) {
        this.connection = connection;
        setTitle("Log In");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);
        JPanel panel = new JPanel();
        panel.setLayout(null);
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(20, 20, 80, 25);
        panel.add(usernameLabel);
        usernameField = new JTextField();
        usernameField.setBounds(100, 20, 160, 25);
        panel.add(usernameField);
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(20, 50, 80, 25);
        panel.add(passwordLabel);
        passwordField = new JPasswordField();
        passwordField.setBounds(100, 50, 160, 25);
        panel.add(passwordField);
        logInButton = new JButton("Log In");
        logInButton.setBounds(100, 90, 100, 25);
        logInButton.addActionListener(new LogInListener());
        panel.add(logInButton);
        add(panel);
    }

    public void displayLogin() {
        this.setVisible(true);
    }

    private class LogInListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String name = usernameField.getText();
            String password = new String(passwordField.getPassword());

            try {
                String selectQuery = "SELECT id FROM signUp WHERE name = ? AND password = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(selectQuery)) {
                    preparedStatement.setString(1, name);
                    preparedStatement.setString(2, password);
                    ResultSet resultSet = preparedStatement.executeQuery();
                    if (resultSet.next()) {
                        int userID = resultSet.getInt("id");
                        dispose();
                        UserDashboard userDashboard = new UserDashboard(connection, userID);
                        userDashboard.displayDashboard();
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid username or password");
                    }
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error logging in. Please try again.");
            }
        }
    }
}
