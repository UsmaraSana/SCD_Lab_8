/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab_8;

import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class LAB_8 {

    public static void main(String[] args) {
        Connection connection = null;
        try {
            String url = "jdbc:mysql://localhost:3306/lab8";
            String user = "root";
            String password = "Usmara475";
            connection = DriverManager.getConnection(url, user, password);
            LogIn loginForm = new LogIn(connection);
            loginForm.displayLogin();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error connecting to the database.");
        }
    }
}
