
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author hp
 */
package lab_8;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class UserDashboard extends JFrame {

    private Connection connection;
    private JTextArea inboxTextArea;
    private JTextArea sentBoxTextArea;
    private int userID;

    public UserDashboard(Connection connection, int userID) {
        this.connection = connection;
        this.userID = userID;

        setTitle("User Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);
        JTabbedPane tabbedPane = new JTabbedPane();
        JPanel inboxPanel = new JPanel(new BorderLayout());
        inboxTextArea = new JTextArea(20, 40);
        inboxTextArea.setEditable(false);
        JScrollPane inboxScrollPane = new JScrollPane(inboxTextArea);
        inboxPanel.add(inboxScrollPane, BorderLayout.CENTER);
        tabbedPane.addTab("Inbox", inboxPanel);
        JPanel sentBoxPanel = new JPanel(new BorderLayout());
        sentBoxTextArea = new JTextArea(20, 40);
        sentBoxTextArea.setEditable(false);
        JScrollPane sentBoxScrollPane = new JScrollPane(sentBoxTextArea);
        sentBoxPanel.add(sentBoxScrollPane, BorderLayout.CENTER);
        tabbedPane.addTab("Sent Box", sentBoxPanel);
        JPanel sendMessagePanel = new JPanel();
        sendMessagePanel.setLayout(null);
        JLabel recipientLabel = new JLabel("Recipient's User ID:");
        recipientLabel.setBounds(20, 20, 120, 25);
        sendMessagePanel.add(recipientLabel);
        JTextField recipientField = new JTextField();
        recipientField.setBounds(150, 20, 160, 25);
        sendMessagePanel.add(recipientField);
        JLabel messageLabel = new JLabel("Message:");
        messageLabel.setBounds(20, 50, 80, 25);
        sendMessagePanel.add(messageLabel);
        JTextArea messageTextArea = new JTextArea(5, 20);
        JScrollPane messageScrollPane = new JScrollPane(messageTextArea);
        messageScrollPane.setBounds(20, 80, 550, 200);
        sendMessagePanel.add(messageScrollPane);
        JButton sendButton = new JButton("Send");
        sendButton.setBounds(200, 300, 100, 25);
        sendMessagePanel.add(sendButton);
        tabbedPane.addTab("Send Message", sendMessagePanel);

        sendButton.addActionListener(e -> {
            String recipientID = recipientField.getText();
            String message = messageTextArea.getText();
            try {
                String insertQuery = "INSERT INTO Messages (senderId, recipientId, messageContent) VALUES (?, ?, ?)";
                PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
                insertStatement.setInt(1, userID); // Set the sender's user ID
                insertStatement.setString(2, recipientID);
                insertStatement.setString(3, message);
                insertStatement.executeUpdate();

                sentBoxTextArea.append("To: " + recipientID + "\n" + message + "\n\n");
                JOptionPane.showMessageDialog(null, "Message sent successfully!");
                recipientField.setText("");
                messageTextArea.setText("");

                fetchSentMessagesForUser();
                fetchReceivedMessagesForUser();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error sending message.");
            }
        });
        fetchSentMessagesForUser();
        fetchReceivedMessagesForUser();
        add(tabbedPane);
    }

    public void displayDashboard() {
        setVisible(true);
    }

    private void fetchSentMessagesForUser() {
        try {
            String query = "SELECT * FROM Messages WHERE senderId = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userID);
            ResultSet resultSet = preparedStatement.executeQuery();

            StringBuilder messages = new StringBuilder();
            while (resultSet.next()) {
                int recipientId = resultSet.getInt("recipientId");
                String messageContent = resultSet.getString("messageContent");
                messages.append("To: ").append(recipientId).append("\n").append(messageContent).append("\n\n");
            }
            sentBoxTextArea.setText(messages.toString());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error fetching sent messages.");
        }
    }

    private void fetchReceivedMessagesForUser() {
        try {
            String query = "SELECT * FROM Messages WHERE recipientId = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userID);
            ResultSet resultSet = preparedStatement.executeQuery();

            StringBuilder messages = new StringBuilder();
            while (resultSet.next()) {
                int senderId = resultSet.getInt("senderId");
                String messageContent = resultSet.getString("messageContent");
                messages.append("From: ").append(senderId).append("\n").append(messageContent).append("\n\n");
            }
            inboxTextArea.setText(messages.toString());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error fetching received messages.");
        }
    }
}
