/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab_8;

/**
 *
 * @author hp
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class SignUpForm extends JFrame {

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField emailField;
    private JButton signUpButton;

    public SignUpForm() {
        setTitle("Sign Up");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);
        setLayout(null);
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(20, 20, 80, 25);
        add(usernameLabel);
        usernameField = new JTextField();
        usernameField.setBounds(100, 20, 160, 25);
        add(usernameField);
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(20, 50, 80, 25);
        add(passwordLabel);
        passwordField = new JPasswordField();
        passwordField.setBounds(100, 50, 160, 25);
        add(passwordField);
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(20, 80, 80, 25);
        add(emailLabel);
        emailField = new JTextField();
        emailField.setBounds(100, 80, 160, 25);
        add(emailField);
        signUpButton = new JButton("Sign Up");
        signUpButton.setBounds(100, 120, 100, 25);
        signUpButton.addActionListener(new SignUpListener());
        add(signUpButton);
    }

    private class SignUpListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            String name = usernameField.getText();
            char[] passwordChars = passwordField.getPassword();
            String email = emailField.getText();
            String password = new String(passwordChars);
            try {
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(SignUpForm.class.getName()).log(Level.SEVERE, null, ex);
                }
                Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/lab8", "root", "Usmara475");
                String insertQuery = "INSERT INTO signUp (name, password, email) VALUES (?, ?, ?)";
                PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
                preparedStatement.setString(1, name);
                preparedStatement.setString(2, password);
                preparedStatement.setString(3, email);
                preparedStatement.executeUpdate();
                preparedStatement.close();
                connection.close();
                JOptionPane.showMessageDialog(null, "User signed up successfully!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error signing up. Please try again.");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SignUpForm signUpForm = new SignUpForm();
            signUpForm.setVisible(true);
        });
    }
}
